import sqlite3
from flask import Flask, render_template, request, session, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'some_unique_and_secret_key_123'

def get_db_connection():
    conn = sqlite3.connect('databases.db')
    conn.row_factory = sqlite3.Row
    return conn

with get_db_connection() as conn:
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    
with get_db_connection() as conn:
    conn.execute('''
        CREATE TABLE IF NOT EXISTS user_films (
            user_id INTEGER,
            film_id INTEGER,
            PRIMARY KEY (user_id, film_id)
        )
    ''')

with get_db_connection() as conn:
    conn.execute('''
        CREATE TABLE IF NOT EXISTS user_series (
            user_id INTEGER,
            series_id INTEGER,
            PRIMARY KEY (user_id, series_id)
        )
    ''')

get_db_connection()
@app.route('/')
def home():
    current_theme = session.get('theme', 'dark')
    return render_template('base.html', theme=current_theme)

@app.route('/toggle-theme', methods=['POST'])
def toggle_theme():
    if session.get('theme') == 'light':
        session['theme'] = 'dark'
    else:
        session['theme'] = 'light'
    return redirect(request.referrer or url_for('home'))

@app.route('/filmlist')
def filmlist():
    conn = get_db_connection()
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM FILM")
    films_data = cursor.fetchall()
    
    conn.close()
    return render_template('filmlist.html', theme=session.get('theme', 'dark'), films=films_data)

@app.route('/serieslist')
def serieslist():
    conn = get_db_connection()

    cursor = conn.cursor()
    cursor.execute("SELECT * FROM SERIE")
    series_data = cursor.fetchall()
    
    conn.close()
    return render_template('serieslist.html', theme=session.get('theme', 'dark'), series=series_data)



@app.route('/add-to-personal', methods=['POST'])
def add_to_personal():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    film_id = request.form.get('film_id')
    user_id = session['user_id']
    
    conn = get_db_connection()
    existing = conn.execute('SELECT * FROM user_films WHERE user_id = ? AND film_id = ?', (user_id, film_id)).fetchone()
    
    if not existing:
        conn.execute('INSERT INTO user_films (user_id, film_id) VALUES (?, ?)', (user_id, film_id))
        conn.commit()
        return("Successfully added to your list!")
    else:
        return("This is already in your list!")
    

@app.route('/add-series-to-personal', methods=['POST'])
def add_series_to_personal():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    series_id = request.form.get('series_id')
    user_id = session['user_id']

    conn = get_db_connection()
    existing = conn.execute('SELECT * FROM user_series WHERE user_id = ? AND series_id = ?', 
                            (user_id, series_id)).fetchone()

    if not existing:
        conn.execute('INSERT INTO user_series (user_id, series_id) VALUES (?, ?)', (user_id, series_id))
        conn.commit()
        conn.close() # Always close your connection
        return("Successfully added series to your list!")
    else:
        conn.close()
        return("This series is already in your list!")

@app.route('/personallist')
def personallist():
    return render_template('personallist.html', theme=session.get('theme', 'dark'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        try:
            conn = get_db_connection()
            conn.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
            conn.commit()
            conn.close()
            return redirect(url_for('login'))
        except:
            return "Username already taken! Go back and try again."
            
    return render_template('signup.html', theme=session.get('theme', 'dark'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        cursor = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password)) 
        user = cursor.fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['Id']
            session['username'] = user['username']
            return redirect(url_for('home'))
        else:
            return "Wrong username or password!"
            
    return render_template('login.html', theme=session.get('theme', 'dark'))

@app.route('/account')
def account():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    else:
        return render_template('account.html', username=session.get('username'), theme=session.get('theme', 'dark'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/filmsperlist')
def filmside():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    # This SQL joins the link table with the FILM table to get the titles/images
    user_films = conn.execute('''SELECT FILM.* FROM FILM 
        JOIN user_films ON FILM.id = user_films.film_id 
        WHERE user_films.user_id = ?
    ''', (session['user_id'],)).fetchall()
    conn.close()

    return render_template('personallist.html', films=user_films, theme=session.get('theme', 'dark'), page='films')

@app.route('/seriesperlist')
def seriesside():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    # Using SERIE (singular) to match your database screenshot
    user_series = conn.execute('''SELECT SERIE.* FROM SERIE
        JOIN user_series ON SERIE.id = user_series.series_id
        WHERE user_series.user_id = ?
    ''', (session['user_id'],)).fetchall()
    conn.close()

    return render_template('personallist.html', series=user_series, theme=session.get('theme', 'dark'), page='series')



if __name__ == '__main__':
    app.run(debug=True)
